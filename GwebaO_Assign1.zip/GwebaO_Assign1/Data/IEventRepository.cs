﻿using GwebaO_Assign1.Models;

namespace GwebaO_Assign1.Data
{
    public interface IEventRepository
    {
        IEnumerable<Event> GetAllEvents();
        Event GetEventById(int eventId);
        Event GetEventWithAttendees(int eventId);
        void AddAttendee(Attendee attendee);
        void SaveChanges();
    }

}
