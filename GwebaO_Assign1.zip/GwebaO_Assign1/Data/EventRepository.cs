﻿using GwebaO_Assign1.Models;
using GwebaO_Assign1.Controllers;
using Microsoft.EntityFrameworkCore;

namespace GwebaO_Assign1.Data
{
    public class EventRepository : IEventRepository
    {
        private readonly AppDbContext _appDbcontext;

        public EventRepository(AppDbContext context)
        {
            _appDbcontext = context;
        }

        public IEnumerable<Event> GetAllEvents()
        {
            return _appDbcontext.Events;
        }

        public Event GetEventById(int eventId)
        {
            return _appDbcontext.Events.FirstOrDefault(e => e.EventId == eventId);
        }

        public Event GetEventWithAttendees(int eventId)
        {
            return _appDbcontext.Events.Include(e => e.Attendees)
                           .FirstOrDefault(e => e.EventId == eventId);
        }

        public void AddAttendee(Attendee attendee)
        {
            var EventToUpdate = _appDbcontext.Events.Include(e => e.Attendees)
        .FirstOrDefault(e => e.EventId == attendee.EventId);

            if (EventToUpdate != null && EventToUpdate.Attendees.Count < EventToUpdate.EventMaxAttendees)
            {
                _appDbcontext.Attendees.Add(attendee);

            }
        }
        public void SaveChanges()
        {
            _appDbcontext.SaveChanges();
        }

    }
}