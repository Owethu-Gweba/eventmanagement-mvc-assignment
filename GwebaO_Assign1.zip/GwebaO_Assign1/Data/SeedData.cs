﻿using GwebaO_Assign1.Models;
using GwebaO_Assign1.Controllers;
using Microsoft.EntityFrameworkCore;
using System;

namespace GwebaO_Assign1.Data
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            AppDbContext context = app.ApplicationServices
                .CreateScope().ServiceProvider.GetRequiredService<AppDbContext>();

            if (context.Database.GetPendingMigrations().Any())
            {
                context.Database.Migrate();
            }

            if (!context.Events.Any())
            {
                context.Events.AddRange(
                    new Event
                    {
                        EventTitle = "Green Future Expo 2025",
                        EventDescription = "A showcase of sustainable technologies and eco-friendly innovations.",
                        EventStartDate = new DateTime(2025, 3, 10),
                        EventEndDate = new DateTime(2025, 3, 12),
                        EventLocation = "Cape Town International Convention Centre",
                        EventMaxAttendees = 1000
                    },

                   new Event
                   {
                       EventTitle = "Comedy Night Show",
                       EventDescription = "South African's best comedians are hosting a comedy stand up show for 24 hours.",
                       EventStartDate = new DateTime(2025, 4, 3),
                       EventEndDate = new DateTime(2025, 4, 4),
                       EventLocation = "Johannesburg Innovation Hub",
                       EventMaxAttendees = 200,
                       EventRegistrations=0
                   },

                  new Event
                  {
                      EventTitle = "Virtual Reality Game Gig",
                      EventDescription = "Teams compete to build the most creative VR game in 48 hours.",
                      EventStartDate = new DateTime(2025, 6, 11),
                      EventEndDate = new DateTime(2025, 6, 15),
                      EventLocation = "Durban Tech Labs",
                      EventMaxAttendees = 100
                  }
                );
                context.SaveChanges();
            }

        }
    }
}
