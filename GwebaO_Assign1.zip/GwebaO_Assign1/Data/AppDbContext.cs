﻿using GwebaO_Assign1.Models; 
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using System.IO;
namespace GwebaO_Assign1.Controllers
{
    public class AppDbContext: DbContext 
    { 
        public AppDbContext(DbContextOptions<AppDbContext> options) 
            : base(options) 
        { 
 
        } 
 
        public DbSet<Event> Events { get; set; } 
        public DbSet<Attendee> Attendees { get; set; } 
 
        protected override void OnModelCreating(ModelBuilder modelBuilder) 
        { 
            base.OnModelCreating(modelBuilder); 
 
            modelBuilder.Entity<Event>().ToTable("Event"); 
            modelBuilder.Entity<Attendee>().ToTable("Attendee"); 
        } 
    } 
}