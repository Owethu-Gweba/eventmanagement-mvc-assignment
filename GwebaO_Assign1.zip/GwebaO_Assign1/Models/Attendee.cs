﻿using GwebaO_Assign1.Models;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace GwebaO_Assign1.Models
{
    public class Attendee
    {
        public int AttendeeId { get; set; }

        [Required(ErrorMessage = "Please enter your name")]
        [DisplayName("Name")]
        public string AttendeeName { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [RegularExpression(".+\\@.+\\..+",
            ErrorMessage = "Please enter a valid email address")]
        [DisplayName("Email")]
        public string AttendeeEmail { get; set; }

        [Required]
        public int EventId { get; set; }

        public Event Event { get; set; }
    }
}