﻿using GwebaO_Assign1.Data;
using Microsoft.AspNetCore.Mvc;

namespace GwebaO_Assign1.Controllers
{
    public class EventController : Controller
    {
        private readonly IEventRepository _eventRepository;

        public EventController(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        [HttpGet]
        public IActionResult Index()
        {
            return View(_eventRepository.GetAllEvents()
                           .OrderBy(e => e.EventStartDate));
        }
        public IActionResult Details(int eventId)
        {
            var events = _eventRepository.GetEventById(eventId);
            if (events == null)
            {
                return NotFound();
            }
            return View(events);

        }
    }
}
