﻿using GwebaO_Assign1.Data;
using GwebaO_Assign1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GwebaO_Assign1.Controllers
{
    public class AttendeeController : Controller
    {
        private readonly IEventRepository _eventRepository;

        public AttendeeController(IEventRepository eventRepository)
        {
            _eventRepository = eventRepository;
        }

        [HttpGet]
        public IActionResult Register(int eventId)
        {
            var eventDetails = _eventRepository.GetEventById(eventId);
            if (eventDetails == null)
            {
                return NotFound();
            }

            var registration = new Attendee { EventId = eventId };
            return View(registration);
        }


        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Register(Attendee attendee)
        {
            if (ModelState.IsValid)
            {
                try
                {
                    var Event = _eventRepository.GetEventById(attendee.EventId);
                    if (Event != null)
                    {
                        Event.EventRegistrations++;
                    }
                    _eventRepository.AddAttendee(attendee);
                    _eventRepository.SaveChanges();

                    return RedirectToAction("Confirmation", new { EventId= attendee.EventId});

                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes." +
                        "Try again, and if the problem persists, " + "contact your system administrator.");
                }
            }
            return View(attendee);
        }

        [HttpGet]
        public IActionResult Confirmation(int eventId)
        {
            var myEvent = _eventRepository.GetEventWithAttendees(eventId);
            if (myEvent == null)
            {
                return NotFound();
            }
            return View(myEvent);
        }

    }
}
